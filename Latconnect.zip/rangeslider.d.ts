declare module "react-range-slider-input" {
  const rangeslider: any;
  export default rangeslider;
}
