import BlocksInvoiceMain from "@/components/blocksInvoice/BlocksInvoiceMain";

export default function BlocksInvoice() {
  return <BlocksInvoiceMain />;
}
