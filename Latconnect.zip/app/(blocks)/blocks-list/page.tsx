import BlocksListMain from "@/components/blocksList/BlocksListMain";

export default function BlocksList() {
  return <BlocksListMain />;
}
