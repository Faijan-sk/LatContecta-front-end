import Banner from '@/components/otherBillPayments/water/Banner'

export default function Water() {
  return <Banner />
}
