import Banner from '@/components/otherBillPayments/Others'

export default function Water() {
  return <Banner />
}
