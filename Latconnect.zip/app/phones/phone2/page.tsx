import Banner from '@/components/phone2/Banner'

export default function Phone2() {
  return <Banner />
}
