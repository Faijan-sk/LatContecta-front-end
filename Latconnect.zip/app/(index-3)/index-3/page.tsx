import HomeThreeMain from "@/components/homeThree/HomeThreeMain";

export default function HomeThree() {
  return <HomeThreeMain />;
}
