import Banner from "@/components/card/Banner";

export default function Card() {
  return <Banner />;
}
