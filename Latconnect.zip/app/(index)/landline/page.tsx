import Banner from "@/components/landline/Banner";

export default function Landline() {
  return <Banner />;
}
