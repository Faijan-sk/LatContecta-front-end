import Banner from "@/components/electricity/Banner";

export default function Electricity() {
  return <Banner />;
}
