import Banner from "@/components/water/Banner";

export default function Water() {
  return <Banner />;
}
