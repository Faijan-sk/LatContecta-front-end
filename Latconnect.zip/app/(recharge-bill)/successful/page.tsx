import SuccessfulMain from "@/components/successful/SuccessfulMain";

export default function Successful() {
  return <SuccessfulMain />;
}
