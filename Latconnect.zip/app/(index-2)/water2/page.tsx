import Banner from "@/components/water2/Banner";

export default function Water2() {
  return <Banner />;
}
