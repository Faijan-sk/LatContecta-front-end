import Banner from "@/components/card2/Banner";

export default function Card2() {
  return <Banner />;
}
