import Banner from "@/components/homeTwo/Banner";

export default function HomeTwo() {
  return <Banner />;
}
