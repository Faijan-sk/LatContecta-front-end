import Banner from "@/components/electricity2/Banner";

export default function Electricity2() {
  return <Banner />;
}
