import Banner from "@/components/landline2/Banner";

export default function Landline2() {
  return <Banner />;
}
