const faqData = [
  {
    id: 'collapseOne',
    question: 'What is Mobile Top-Up?',
    answer:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when",
  },
  {
    id: 'collapseTwo',
    question: 'How to claim gift cards?',
    answer:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when",
  },
  {
    id: 'collapseThree',
    question: 'How Bill Payment Works?',
    answer:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when",
  },
  {
    id: 'collapseThreem',
    question: 'What is recharge application?',
    answer:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when",
  },
  {
    id: 'collapseThreemm',
    question: 'How do I recharge a phone number?',
    answer:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when",
  },
  {
    id: 'collapseThreemmm',
    question:
      'What is the primary function of the recharge payment application?',
    answer:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when",
  },
]

export default faqData
