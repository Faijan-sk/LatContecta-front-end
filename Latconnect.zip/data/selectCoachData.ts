import a from "/public/img/allseat/a.png";
import b from "/public/img/allseat/b.png";
import c from "/public/img/allseat/c.png";
import d from "/public/img/allseat/d.png";
import e from "/public/img/allseat/e.png";
import f from "/public/img/allseat/f.png";
import g from "/public/img/allseat/g.png";
import h from "/public/img/allseat/h.png";
import i from "/public/img/allseat/i.png";
import j from "/public/img/allseat/j.png";
import k from "/public/img/allseat/k.png";
import l from "/public/img/allseat/l.png";
import m from "/public/img/allseat/m.png";
import n from "/public/img/allseat/n.png";
import o from "/public/img/allseat/o.png";
import p from "/public/img/allseat/p.png";
import q from "/public/img/allseat/q.png";
import r from "/public/img/allseat/r.png";
import s from "/public/img/allseat/s.png";
import t from "/public/img/allseat/t.png";
import u from "/public/img/allseat/u.png";
import v from "/public/img/allseat/v.png";
import w from "/public/img/allseat/w.png";
import y from "/public/img/allseat/y.png";
import z from "/public/img/allseat/z.png";

const selectCoachData = [
  a,
  b,
  c,
  d,
  e,
  f,
  g,
  h,
  i,
  j,
  k,
  l,
  m,
  n,
  o,
  p,
  q,
  r,
  s,
  t,
  u,
  v,
  w,
  y,
  z,
];

export default selectCoachData;
