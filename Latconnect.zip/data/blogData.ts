import list1 from "/public/img/blog/list1.jpg";
import list2 from "/public/img/blog/list2.jpg";
import list3 from "/public/img/blog/list3.jpg";
import list4 from "/public/img/blog/list4.jpg";
import list5 from "/public/img/blog/list5.jpg";
import list6 from "/public/img/blog/list6.jpg";

const blogData = [
  {
    id: 1,
    title: "Why you should think twice before booking the Maldives...",
    desc: "There are many variations of passages of Lorem ipsum available, but the majority have sufferrd alteration in some form...",
    img: list1,
    comment_number: 15,
    author: "Admin",
  },
  {
    id: 2,
    title: "Flight booking service integrated with Rechargio Pilot eTravel...",
    desc: "There are many variations of passages of Lorem ipsum available, but the majority have sufferrd alteration in some form...",
    img: list2,
    comment_number: 15,
    author: "Admin",
  },
  {
    id: 3,
    title: "American Airlines brings back free 24-hour reservation hold...",
    desc: "There are many variations of passages of Lorem ipsum available, but the majority have sufferrd alteration in some form...",
    img: list3,
    comment_number: 15,
    author: "Admin",
  },
  {
    id: 4,
    title: "Rechargio rectifies technical Smart in bill payment service...",
    desc: "There are many variations of passages of Lorem ipsum available, but the majority have sufferrd alteration in some form...",
    img: list4,
    comment_number: 15,
    author: "Admin",
  },
  {
    id: 5,
    title: "Credit card bill payment platform Cred acquires Rechargio...",
    desc: "There are many variations of passages of Lorem ipsum available, but the majority have sufferrd alteration in some form...",
    img: list5,
    comment_number: 15,
    author: "Admin",
  },
  {
    id: 6,
    title: "Rechargio announces new album, world tour...",
    desc: "There are many variations of passages of Lorem ipsum available, but the majority have sufferrd alteration in some form...",
    img: list6,
    comment_number: 15,
    author: "Admin",
  },
];

export default blogData;
