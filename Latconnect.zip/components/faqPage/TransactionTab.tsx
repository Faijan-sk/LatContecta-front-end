const TransactionTab = () => {
  return (
    <div className="qustion__content">
      <div className="accordion__wrap">
        <div className="accordion" id="accordionExample4">
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="0.9s">
            <h2 className="accordion-header" id="headingOne4">
              <button
                className="accordion-button"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseOne4"
                aria-expanded="true"
                aria-controls="collapseOne4"
              >
                What is e recharge?
              </button>
            </h2>
            <div
              id="collapseOne4"
              className="accordion-collapse collapse show"
              aria-labelledby="headingOne4"
              data-bs-parent="#accordionExample4"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1s">
            <h2 className="accordion-header" id="headingTwo4">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseTwo4"
                aria-expanded="false"
                aria-controls="collapseTwo4"
              >
                What is recharge credit?
              </button>
            </h2>
            <div
              id="collapseTwo4"
              className="accordion-collapse collapse"
              aria-labelledby="headingTwo4"
              data-bs-parent="#accordionExample4"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1.4s">
            <h2 className="accordion-header" id="headingThree4">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThree4"
                aria-expanded="false"
                aria-controls="collapseThree4"
              >
                How reliable is recharge com?
              </button>
            </h2>
            <div
              id="collapseThree4"
              className="accordion-collapse collapse"
              aria-labelledby="headingThree4"
              data-bs-parent="#accordionExample4"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1.6s">
            <h2 className="accordion-header" id="headingThreem4">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThreem4"
                aria-expanded="false"
                aria-controls="collapseThreem4"
              >
                What is recharge application?
              </button>
            </h2>
            <div
              id="collapseThreem4"
              className="accordion-collapse collapse"
              aria-labelledby="headingThreem4"
              data-bs-parent="#accordionExample4"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1.8s">
            <h2 className="accordion-header" id="headingThreemm4">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThreemm4"
                aria-expanded="false"
                aria-controls="collapseThreemm4"
              >
                How do I recharge a phone number?
              </button>
            </h2>
            <div
              id="collapseThreemm4"
              className="accordion-collapse collapse"
              aria-labelledby="headingThreemm4"
              data-bs-parent="#accordionExample4"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1.9s">
            <h2 className="accordion-header" id="headingThreemmm4">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThreemmm4"
                aria-expanded="false"
                aria-controls="collapseThreemmm4"
              >
                What is the primary function of the recharge payment
                application?
              </button>
            </h2>
            <div
              id="collapseThreemmm4"
              className="accordion-collapse collapse"
              aria-labelledby="headingThreemmm4"
              data-bs-parent="#accordionExample4"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
        </div>
      </div>
    </div>
  )
}

export default TransactionTab
