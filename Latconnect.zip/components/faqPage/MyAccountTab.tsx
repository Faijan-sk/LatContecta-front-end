const MyAccountTab = () => {
  return (
    <div className="qustion__content">
      <div className="accordion__wrap">
        <div className="accordion" id="accordionExample6">
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1.4s">
            <h2 className="accordion-header" id="headingThree6">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThree6"
                aria-expanded="false"
                aria-controls="collapseThree6"
              >
                How reliable is recharge com?
              </button>
            </h2>
            <div
              id="collapseThree6"
              className="accordion-collapse collapse"
              aria-labelledby="headingThree6"
              data-bs-parent="#accordionExample6"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1.6s">
            <h2 className="accordion-header" id="headingThreem6">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThreem6"
                aria-expanded="false"
                aria-controls="collapseThreem6"
              >
                What is recharge application?
              </button>
            </h2>
            <div
              id="collapseThreem6"
              className="accordion-collapse collapse"
              aria-labelledby="headingThreem6"
              data-bs-parent="#accordionExample6"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1.8s">
            <h2 className="accordion-header" id="headingThreemm6">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThreemm6"
                aria-expanded="false"
                aria-controls="collapseThreemm6"
              >
                How do I recharge a phone number?
              </button>
            </h2>
            <div
              id="collapseThreemm6"
              className="accordion-collapse collapse"
              aria-labelledby="headingThreemm6"
              data-bs-parent="#accordionExample6"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
          <div className="accordion-item wow fadeInUp" data-wow-duration="1.9s">
            <h2 className="accordion-header" id="headingThreemmm6">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThreemmm6"
                aria-expanded="false"
                aria-controls="collapseThreemmm6"
              >
                What is the primary function of the recharge payment
                application?
              </button>
            </h2>
            <div
              id="collapseThreemmm6"
              className="accordion-collapse collapse"
              aria-labelledby="headingThreemmm6"
              data-bs-parent="#accordionExample6"
            >
              <div className="accordion-body">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry&#39;s
                  standard dummy text ever since the 1500s, when
                </p>
              </div>
            </div>
          </div>
          {/* Accordion items */}
        </div>
      </div>
    </div>
  );
};

export default MyAccountTab;
