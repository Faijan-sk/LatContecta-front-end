import Electricity2 from '@/app/(index-2)/electricity2/page'
import React from 'react'

function BillPaymentPage() {
  return (
    <>
      <Electricity2 />
    </>
  )
}

export default BillPaymentPage
